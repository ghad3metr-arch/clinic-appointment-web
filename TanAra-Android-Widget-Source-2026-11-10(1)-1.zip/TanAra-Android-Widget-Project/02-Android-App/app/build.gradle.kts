plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.tanara.widget"
    compileSdk = 36

    defaultConfig {
        applicationId = "ir.tanara.widget"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.12.0")
}
