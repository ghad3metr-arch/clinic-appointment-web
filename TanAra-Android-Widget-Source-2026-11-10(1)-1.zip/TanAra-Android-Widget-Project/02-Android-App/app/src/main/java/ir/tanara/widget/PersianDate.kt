package ir.tanara.widget

import android.icu.util.PersianCalendar
import android.icu.util.Calendar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object PersianDate {
    private val tehran = ZoneId.of("Asia/Tehran")
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    fun todayIso(): String = LocalDate.now(tehran).format(iso)
    fun tomorrowIso(): String = LocalDate.now(tehran).plusDays(1).format(iso)

    fun jalaliToday(): String = jalali(Date.from(LocalDate.now(tehran).atStartOfDay(tehran).toInstant()))
    fun jalaliTomorrow(): String = jalali(Date.from(LocalDate.now(tehran).plusDays(1).atStartOfDay(tehran).toInstant()))

    private fun jalali(date: Date): String {
        val calendar = PersianCalendar(TimeZone.getTimeZone("Asia/Tehran"))
        calendar.time = date
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        return fa("%04d/%02d/%02d".format(Locale.US, year, month, day))
    }

    fun fa(value: String): String = value.map { ch ->
        if (ch in '0'..'9') ('۰'.code + (ch.code - '0'.code)).toChar() else ch
    }.joinToString("")
}
