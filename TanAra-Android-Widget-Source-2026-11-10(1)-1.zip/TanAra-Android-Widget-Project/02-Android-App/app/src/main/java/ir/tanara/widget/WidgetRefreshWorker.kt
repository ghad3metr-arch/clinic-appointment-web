package ir.tanara.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.Worker
import androidx.work.WorkerParameters

class WidgetRefreshWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val manager = AppWidgetManager.getInstance(applicationContext)
        val ids = manager.getAppWidgetIds(ComponentName(applicationContext, TanAraWidgetProvider::class.java))
        if (ids.isEmpty()) return Result.success()
        return try {
            val data = WidgetDataRepository.fetch(applicationContext)
            ids.forEach { WidgetRenderer.render(applicationContext, it, data) }
            Result.success()
        } catch (_: WidgetDataRepository.NoWidgetSessionException) {
            ids.forEach { WidgetRenderer.renderSignInRequired(applicationContext, it) }
            Result.success()
        } catch (_: Exception) {
            // Keep the last successful widget content visible during temporary network errors.
            Result.retry()
        }
    }

    companion object {
        fun networkConstraints(): Constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
    }
}
