package ir.tanara.widget

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.SslErrorHandler
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.SslError
import android.widget.ProgressBar
import android.widget.TextView
import android.app.Activity

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var loading: ProgressBar
    private lateinit var errorText: TextView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.office_webview)
        loading = findViewById(R.id.loading)
        errorText = findViewById(R.id.error_text)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            safeBrowsingEnabled = true
        }
        webView.addJavascriptInterface(WidgetBridge(applicationContext), "AndroidWidget")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                loading.visibility = View.GONE
                errorText.visibility = View.GONE
                WidgetScheduler.install(applicationContext)
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val target = request?.url ?: return false
                if (target.scheme == "https" && target.host == SITE_HOST) return false
                if (target.scheme == "tel" || target.scheme == "mailto" || target.scheme == "https" || target.scheme == "http") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, target)) }
                    return true
                }
                return true
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
                loading.visibility = View.GONE
                errorText.visibility = View.VISIBLE
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    loading.visibility = View.GONE
                    errorText.visibility = View.VISIBLE
                }
            }
        }
        loadOffice(intent)
        WidgetScheduler.install(applicationContext)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        loadOffice(intent)
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) WidgetScheduler.refreshNow(applicationContext)
    }

    private fun loadOffice(source: Intent?) {
        val appointmentId = source?.getStringExtra(EXTRA_APPOINTMENT_ID)
        val uri = Uri.parse(SITE_URL).buildUpon().apply {
            if (!appointmentId.isNullOrBlank()) appendQueryParameter("appointment", appointmentId)
        }.build()
        loading.visibility = View.VISIBLE
        errorText.visibility = View.GONE
        webView.loadUrl(uri.toString())
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    companion object {
        const val EXTRA_APPOINTMENT_ID = "tanara_appointment_id"
        private const val SITE_HOST = "deluxe-swan-05920c.netlify.app"
        private const val SITE_URL = "https://deluxe-swan-05920c.netlify.app/"
    }
}
