package ir.tanara.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

object WidgetRenderer {
    fun render(context: Context, widgetId: Int, data: WidgetData) {
        val views = RemoteViews(context.packageName, R.layout.widget_tanara)
        views.setTextViewText(R.id.widget_today_title, "☀ امروز · ${data.todayLabel}")
        views.setTextViewText(R.id.widget_tomorrow_title, "🌙 فردا · ${data.tomorrowLabel}")
        views.setTextViewText(R.id.widget_today_count, "${PersianDate.fa(data.today.size.toString())} نوبت")
        views.setTextViewText(R.id.widget_tomorrow_count, "${PersianDate.fa(data.tomorrow.size.toString())} نوبت")
        views.setTextViewText(R.id.widget_sync_status, "آخرین دریافت: ${data.updatedLabel}")
        views.removeAllViews(R.id.widget_today_list)
        views.removeAllViews(R.id.widget_tomorrow_list)
        addRows(context, views, R.id.widget_today_list, data.today)
        addRows(context, views, R.id.widget_tomorrow_list, data.tomorrow)
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPendingIntent(context))
        views.setOnClickPendingIntent(R.id.widget_header, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_footer, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_root, openPendingIntent(context, null))
        AppWidgetManager.getInstance(context).updateAppWidget(widgetId, views)
    }

    fun renderSignInRequired(context: Context, widgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_tanara)
        views.setTextViewText(R.id.widget_sync_status, "برای فعال‌سازی، دفتر تن‌آرا را باز و وارد حساب شو")
        views.setTextViewText(R.id.widget_today_title, "☀ نوبت‌های امروز")
        views.setTextViewText(R.id.widget_tomorrow_title, "🌙 نوبت‌های فردا")
        views.setTextViewText(R.id.widget_today_count, "—")
        views.setTextViewText(R.id.widget_tomorrow_count, "—")
        views.removeAllViews(R.id.widget_today_list)
        views.removeAllViews(R.id.widget_tomorrow_list)
        views.setOnClickPendingIntent(R.id.widget_root, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_header, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_footer, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPendingIntent(context))
        AppWidgetManager.getInstance(context).updateAppWidget(widgetId, views)
    }

    private fun addRows(context: Context, parent: RemoteViews, containerId: Int, items: List<WidgetAppointment>) {
        val shown = items.take(4)
        if (shown.isEmpty()) {
            val empty = RemoteViews(context.packageName, R.layout.widget_appointment_row)
            empty.setTextViewText(R.id.row_time, "—")
            empty.setTextViewText(R.id.row_name, "نوبتی ثبت نشده")
            empty.setTextViewText(R.id.row_service, "برنامه فعلاً خالی است")
            parent.addView(containerId, empty)
            return
        }
        shown.forEach { item ->
            val row = RemoteViews(context.packageName, R.layout.widget_appointment_row)
            row.setTextViewText(R.id.row_time, PersianDate.fa(item.time))
            row.setTextViewText(R.id.row_name, item.name)
            val status = when (item.status) {
                "confirmed" -> " · تأییدشده"
                "done" -> " · انجام‌شده"
                "noshow" -> " · عدم مراجعه"
                else -> ""
            }
            val service = item.service.ifBlank { "جلسه" }
            row.setTextViewText(R.id.row_service, service + status)
            row.setOnClickPendingIntent(R.id.appointment_row, openPendingIntent(context, item.id))
            parent.addView(containerId, row)
        }
        if (items.size > shown.size) {
            val extra = RemoteViews(context.packageName, R.layout.widget_appointment_row)
            extra.setTextViewText(R.id.row_time, "+${PersianDate.fa((items.size - shown.size).toString())}")
            extra.setTextViewText(R.id.row_name, "نوبت دیگر")
            extra.setTextViewText(R.id.row_service, "برای دیدن همه، ویجت را باز کن")
            extra.setOnClickPendingIntent(R.id.appointment_row, openPendingIntent(context, null))
            parent.addView(containerId, extra)
        }
    }

    private fun openPendingIntent(context: Context, appointmentId: String?): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (!appointmentId.isNullOrBlank()) putExtra(MainActivity.EXTRA_APPOINTMENT_ID, appointmentId)
        }
        val requestCode = appointmentId?.hashCode() ?: 100
        return PendingIntent.getActivity(context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun refreshPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, TanAraWidgetProvider::class.java).setAction(TanAraWidgetProvider.ACTION_REFRESH)
        return PendingIntent.getBroadcast(context, 200, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
