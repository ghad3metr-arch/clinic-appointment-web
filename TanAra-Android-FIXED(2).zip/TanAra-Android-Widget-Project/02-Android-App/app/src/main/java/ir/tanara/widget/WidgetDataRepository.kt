package ir.tanara.widget

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private const val SUPABASE_URL = "https://bpqjeinlnslcmftzidmg.supabase.co"
private const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_MK8vblyM7EqRu3bY8vEyPA_34oENuJP"
private const val CLOUD_TABLE = "tanara_standalone_appointments"

 data class WidgetAppointment(
    val id: String,
    val name: String,
    val service: String,
    val date: String,
    val time: String,
    val status: String
)

data class WidgetData(
    val today: List<WidgetAppointment>,
    val tomorrow: List<WidgetAppointment>,
    val todayLabel: String,
    val tomorrowLabel: String,
    val updatedLabel: String
)

object WidgetDataRepository {
    fun fetch(context: android.content.Context): WidgetData {
        var session = SessionVault.load(context) ?: throw NoWidgetSessionException()
        if (session.expiresAt <= System.currentTimeMillis() / 1000L + 75L) {
            session = refreshSession(context, session)
        }

        val encodedUser = Uri.encode(session.userId)
        val endpoint = "$SUPABASE_URL/rest/v1/$CLOUD_TABLE?select=payload,updated_at&owner_id=eq.$encodedUser&limit=1"
        var body = request("GET", endpoint, session.accessToken)
        if (body.code == 401 || body.code == 403) {
            session = refreshSession(context, session)
            body = request("GET", endpoint, session.accessToken)
        }
        if (body.code !in 200..299) throw IOException("Supabase Data API returned ${body.code}")

        val rows = JSONArray(body.text)
        val appointments = if (rows.length() > 0) {
            rows.getJSONObject(0).optJSONObject("payload")?.optJSONArray("appointments") ?: JSONArray()
        } else JSONArray()

        val today = PersianDate.todayIso()
        val tomorrow = PersianDate.tomorrowIso()
        val todayItems = mutableListOf<WidgetAppointment>()
        val tomorrowItems = mutableListOf<WidgetAppointment>()
        for (i in 0 until appointments.length()) {
            val a = appointments.optJSONObject(i) ?: continue
            val date = a.optString("date")
            val status = a.optString("status", "booked")
            if (status == "cancelled") continue
            val item = WidgetAppointment(
                id = a.optString("id"),
                name = a.optString("name", "مراجع"),
                service = a.optString("service", "جلسه"),
                date = date,
                time = normalizeTime(a.optString("time", "")),
                status = status
            )
            when (date) {
                today -> todayItems.add(item)
                tomorrow -> tomorrowItems.add(item)
            }
        }
        val byTime = compareBy<WidgetAppointment> { it.time }
        todayItems.sortWith(byTime)
        tomorrowItems.sortWith(byTime)
        val dateFormat = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Tehran") }
        return WidgetData(
            today = todayItems,
            tomorrow = tomorrowItems,
            todayLabel = PersianDate.jalaliToday(),
            tomorrowLabel = PersianDate.jalaliTomorrow(),
            updatedLabel = PersianDate.fa(dateFormat.format(Date()))
        )
    }

    private fun normalizeTime(value: String): String {
        val m = Regex("^(\\d{1,2}):(\\d{2})$").matchEntire(value.trim()) ?: return value
        return "%02d:%s".format(Locale.US, m.groupValues[1].toIntOrNull() ?: 0, m.groupValues[2])
    }

    private data class HttpBody(val code: Int, val text: String)

    private fun request(method: String, endpoint: String, bearer: String?, json: JSONObject? = null): HttpBody {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12_000
            readTimeout = 15_000
            setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY)
            if (!bearer.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $bearer")
            setRequestProperty("Accept", "application/json")
            if (json != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
        try {
            if (json != null) connection.outputStream.use { it.write(json.toString().toByteArray(StandardCharsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() } ?: ""
            return HttpBody(code, text)
        } finally {
            connection.disconnect()
        }
    }

    private fun refreshSession(context: android.content.Context, old: SupabaseSession): SupabaseSession {
        val endpoint = "$SUPABASE_URL/auth/v1/token?grant_type=refresh_token"
        val response = request(
            "POST", endpoint, null,
            JSONObject().put("refresh_token", old.refreshToken)
        )
        if (response.code !in 200..299) throw NoWidgetSessionException()
        val json = JSONObject(response.text)
        val access = json.optString("access_token")
        val refresh = json.optString("refresh_token", old.refreshToken)
        if (access.isBlank()) throw NoWidgetSessionException()
        val updated = SupabaseSession(
            accessToken = access,
            refreshToken = refresh,
            userId = json.optJSONObject("user")?.optString("id")?.takeIf { it.isNotBlank() } ?: old.userId,
            expiresAt = System.currentTimeMillis() / 1000L + json.optLong("expires_in", 3600L)
        )
        SessionVault.save(context, updated)
        return updated
    }

    class NoWidgetSessionException : IOException("Open the Tan Ara app and sign in to enable the widget")
}
