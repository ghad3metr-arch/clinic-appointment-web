package ir.tanara.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

object WidgetRenderer {
    private val todayRows = intArrayOf(
        R.id.today_row_1, R.id.today_row_2, R.id.today_row_3, R.id.today_row_4
    )
    private val tomorrowRows = intArrayOf(
        R.id.tomorrow_row_1, R.id.tomorrow_row_2, R.id.tomorrow_row_3, R.id.tomorrow_row_4
    )

    fun renderLoading(context: Context, widgetId: Int) {
        val views = baseViews(context)
        views.setTextViewText(R.id.widget_sync_status, "در حال اتصال و دریافت نوبت‌ها…")
        views.setTextViewText(R.id.widget_today_count, "…")
        views.setTextViewText(R.id.widget_tomorrow_count, "…")
        setRows(context, views, todayRows, emptyList(), loading = true)
        setRows(context, views, tomorrowRows, emptyList(), loading = true)
        AppWidgetManager.getInstance(context).updateAppWidget(widgetId, views)
    }

    fun render(context: Context, widgetId: Int, data: WidgetData) {
        val views = baseViews(context)
        views.setTextViewText(R.id.widget_today_title, "☀ امروز · ${data.todayLabel}")
        views.setTextViewText(R.id.widget_tomorrow_title, "🌙 فردا · ${data.tomorrowLabel}")
        views.setTextViewText(R.id.widget_today_count, "${PersianDate.fa(data.today.size.toString())} نوبت")
        views.setTextViewText(R.id.widget_tomorrow_count, "${PersianDate.fa(data.tomorrow.size.toString())} نوبت")
        views.setTextViewText(R.id.widget_sync_status, "آخرین دریافت: ${data.updatedLabel}")
        setRows(context, views, todayRows, data.today)
        setRows(context, views, tomorrowRows, data.tomorrow)
        AppWidgetManager.getInstance(context).updateAppWidget(widgetId, views)
    }

    fun renderSignInRequired(context: Context, widgetId: Int) {
        val views = baseViews(context)
        views.setTextViewText(R.id.widget_sync_status, "برای فعال‌سازی، دفتر تن‌آرا را باز کن و وارد حساب شو.")
        views.setTextViewText(R.id.widget_today_count, "—")
        views.setTextViewText(R.id.widget_tomorrow_count, "—")
        setRows(context, views, todayRows, emptyList(), emptyMessage = "ابتدا وارد حساب تن‌آرا شو")
        setRows(context, views, tomorrowRows, emptyList(), emptyMessage = "پس از ورود، نوبت‌ها نمایش داده می‌شوند")
        AppWidgetManager.getInstance(context).updateAppWidget(widgetId, views)
    }

    fun renderError(context: Context, widgetId: Int) {
        val views = baseViews(context)
        views.setTextViewText(R.id.widget_sync_status, "دریافت اطلاعات ناموفق بود؛ دکمه تازه‌سازی را بزن.")
        setRows(context, views, todayRows, emptyList(), emptyMessage = "اتصال موقتاً برقرار نیست")
        setRows(context, views, tomorrowRows, emptyList(), emptyMessage = "اطلاعات قبلی پس از اتصال نمایش داده می‌شود")
        AppWidgetManager.getInstance(context).updateAppWidget(widgetId, views)
    }

    private fun baseViews(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_tanara)
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPendingIntent(context))
        views.setOnClickPendingIntent(R.id.widget_header, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_footer, openPendingIntent(context, null))
        views.setOnClickPendingIntent(R.id.widget_root, openPendingIntent(context, null))
        return views
    }

    private fun setRows(
        context: Context,
        views: RemoteViews,
        rowIds: IntArray,
        items: List<WidgetAppointment>,
        loading: Boolean = false,
        emptyMessage: String = "نوبتی ثبت نشده"
    ) {
        rowIds.forEachIndexed { index, rowId ->
            if (index < items.size && index < rowIds.size) {
                val item = items[index]
                val status = when (item.status) {
                    "confirmed" -> " · تأییدشده"
                    "done" -> " · انجام‌شده"
                    "noshow" -> " · عدم مراجعه"
                    "cancelled" -> " · لغوشده"
                    else -> ""
                }
                val line = "${PersianDate.fa(item.time)}  |  ${item.name}  —  ${item.service}$status"
                views.setTextViewText(rowId, line)
                views.setViewVisibility(rowId, View.VISIBLE)
                views.setOnClickPendingIntent(rowId, openPendingIntent(context, item.id))
            } else if (index == 0 && items.isEmpty()) {
                views.setTextViewText(rowId, if (loading) "در حال دریافت…" else emptyMessage)
                views.setViewVisibility(rowId, View.VISIBLE)
                views.setOnClickPendingIntent(rowId, openPendingIntent(context, null))
            } else {
                views.setViewVisibility(rowId, View.GONE)
            }
        }
    }

    private fun openPendingIntent(context: Context, appointmentId: String?): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (!appointmentId.isNullOrBlank()) putExtra(MainActivity.EXTRA_APPOINTMENT_ID, appointmentId)
        }
        val requestCode = appointmentId?.hashCode() ?: 100
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun refreshPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, TanAraWidgetProvider::class.java)
            .setAction(TanAraWidgetProvider.ACTION_REFRESH)
        return PendingIntent.getBroadcast(
            context, 200, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
