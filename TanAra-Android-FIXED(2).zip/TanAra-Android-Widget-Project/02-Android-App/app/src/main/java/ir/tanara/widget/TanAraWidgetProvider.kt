package ir.tanara.widget

import android.appwidget.AppWidgetProvider
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent

class TanAraWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        // Show a valid, lightweight RemoteViews immediately; do not leave the launcher
        // waiting for the first background network request.
        appWidgetIds.forEach { WidgetRenderer.renderLoading(context, it) }
        WidgetScheduler.install(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) WidgetScheduler.refreshNow(context)
    }

    companion object {
        const val ACTION_REFRESH = "ir.tanara.widget.REFRESH"
    }
}
