package ir.tanara.widget

import android.content.Context
import android.webkit.JavascriptInterface

class WidgetBridge(private val appContext: Context) {
    @JavascriptInterface
    fun setSession(accessToken: String, refreshToken: String, userId: String, expiresAt: String) {
        if (accessToken.isBlank() || refreshToken.isBlank() || userId.isBlank()) return
        val expiry = expiresAt.toLongOrNull() ?: 0L
        runCatching {
            SessionVault.save(appContext, SupabaseSession(accessToken, refreshToken, userId, expiry))
            WidgetScheduler.refreshNow(appContext)
        }
    }

    @JavascriptInterface
    fun onCloudSyncComplete() {
        WidgetScheduler.refreshNow(appContext)
    }

    @JavascriptInterface
    fun clearSession() {
        SessionVault.clear(appContext)
        WidgetScheduler.refreshNow(appContext)
    }
}
