package ir.tanara.widget

import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Gregorian/ISO dates and Jalali labels for the Tehran time zone. */
object PersianDate {
    private val tehran = ZoneId.of("Asia/Tehran")
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE

    fun todayIso(): String = LocalDate.now(tehran).format(iso)
    fun tomorrowIso(): String = LocalDate.now(tehran).plusDays(1).format(iso)

    fun jalaliToday(): String = jalali(LocalDate.now(tehran))
    fun jalaliTomorrow(): String = jalali(LocalDate.now(tehran).plusDays(1))

    private fun jalali(date: LocalDate): String {
        val gYear = date.year
        val gMonth = date.monthValue
        val gDay = date.dayOfMonth

        val gDaysInMonth = intArrayOf(31, if (date.isLeapYear) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val gy = gYear - 1600
        val gm = gMonth - 1
        val gd = gDay - 1

        var gDayNo = 365 * gy + (gy + 3) / 4 - (gy + 99) / 100 + (gy + 399) / 400
        for (i in 0 until gm) gDayNo += gDaysInMonth[i]
        gDayNo += gd

        var jDayNo = gDayNo - 79
        val jNp = jDayNo / 12053
        jDayNo %= 12053

        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461
        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }

        val jm: Int
        val jd: Int
        if (jDayNo < 186) {
            jm = 1 + jDayNo / 31
            jd = 1 + jDayNo % 31
        } else {
            jm = 7 + (jDayNo - 186) / 30
            jd = 1 + (jDayNo - 186) % 30
        }
        return fa(String.format(Locale.US, "%04d/%02d/%02d", jy, jm, jd))
    }

    fun fa(value: String): String = value.map { ch ->
        if (ch in '0'..'9') ('۰'.code + (ch.code - '0'.code)).toChar() else ch
    }.joinToString("")
}
